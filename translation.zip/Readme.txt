This is a translation patch for the RPG maker game "Way too many spoilers RPG" by KSB Games.
Get the game for free here: https://www.freem.ne.jp/win/game/30422 (You will have to make an account.)

To install: Replace the www/data folder in the game files with the contents of the patch.

A new 2.0 patch has since come out for the game. This patch will work on the new version but will downgrade it to the old version.
Some words are untranslated in the game as I couldn't find them in the game files. In the options, the last option is "voice volume". In the menu UI, various "back" options aren't translated.
There is a UI error for Theresa, the icon for her move says "atk down" when the move is a defense debuff. The translation is accurate, I cannot fix the icon.

Have fun!
Fox